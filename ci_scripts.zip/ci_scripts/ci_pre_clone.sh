#!/bin/sh

#  ci_post_clone.sh
#  Xcode cloud testing
#
#  Created by Manish singh on 04/05/25.
#  
echo "Testing: Pre clone staging is running"
